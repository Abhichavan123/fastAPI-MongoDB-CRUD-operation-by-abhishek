from pydantic import BaseModel

class M_app(BaseModel):
    name:str
    email:str
    password:str