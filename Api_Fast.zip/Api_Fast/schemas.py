def info_user(item) -> dict:
    return {
        "id":str(item["_id"]),
        "name":item["name"],
        "email":item["email"],
        "password":item["password"],

    }

def info_users(info)->list:
    user_list=[info_user(item) for item in info]
    return user_list