from schemas import info_user, info_users
from db import db_
from fastapi import HTTPException
from models import M_app
from bson import ObjectId

from fastapi import FastAPI
# from routes import app
F_app = FastAPI()
# F_app.include_router(app)


@F_app.get("/")
async def Read_user():
    get_user= info_users(db_.find())
    if len(get_user)<0:
        raise HTTPException(status_code=404, detail="item not found")
    return get_user
    # return {"test":"test"}



@F_app.get("/{id}")
async def get_one_user(id:str):
    # if id not in :
    #     raise HTTPException(status_code=404, detail="item not found")
    user= info_user(db_.find_one({"_id":ObjectId(id)}))
    return {"status":"ok","data":user}


@F_app.post("/")
async def create_user(info_user:M_app):
    _id=db_.insert_one(dict(info_user))
    user=info_users(db_.find({"_id":_id.inserted_id}))
    return {"status":"ok","data":user}



@F_app.put("/{id}")
async def update_user(id:str,info_user:M_app):
    try:
        db_.find_one_and_update({"_id":ObjectId(id)},
        {
            "$set":dict(info_user)
        })
        user= db_.find({"_id":ObjectId(id)})
        return {"status":"ok","data":user}
    except Exception as e:
        return {"error":e}

@F_app.delete("/{id}")
async def delete_user(id:str):
    db_.find_one_and_delete({"_id":ObjectId(id)})
    return {"status":"ok"}
    