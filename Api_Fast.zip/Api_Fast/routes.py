# from fastapi import FastAPI
# from fastapi import APIRouter
# from fastapi import HTTPException
# from models import M_app
# from db import db_
# from schemas import info_user, info_users
# from bson import ObjectId


# app=APIRouter()


# @app.get("/")
# async def Read_user():
#     # get_user= info_users(db_.find())
#     # if len(get_user)==0:
#     #     raise HTTPException(status_code=404, detail="item not found")
#     # return get_user
#     return {"test":"test"}
